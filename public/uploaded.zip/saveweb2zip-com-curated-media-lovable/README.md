# Curated Media - Lovable Deployment Package

This is an optimized version for Lovable deployment (under 25MB).

## What's Included:
✅ All CSS, JavaScript, and 3D assets
✅ All images (consider optimizing further with TinyPNG)
✅ Essential HTML and config files

## What's Excluded:
❌ `media/` folder (36MB of videos) - Use external CDN
❌ WordPress deployment files

## Next Steps:

1. **Optimize images** (optional but recommended):
   - Go to https://tinypng.com
   - Upload PNG files from `images/` folder
   - Replace with compressed versions
   - Can save ~70% file size!

2. **Handle videos**:
   Your HTML may already reference external video URLs.
   If not, upload videos from original `media/` folder to:
   - Cloudinary (https://cloudinary.com) - Free tier
   - ImageKit (https://imagekit.io) - Free tier
   
   Video files to upload (from original folder):
   - clip1.mp4 (4.4MB)
   - clip2.mp4 (12MB)
   - clip3.mp4 (1.9MB)
   - clip5-v2.mp4 (5.8MB)
   - clip6-new.mp4 (6.5MB)
   - clip7-new.mp4 (4.5MB)

3. **Deploy to Lovable**:
   - Go to https://lovable.dev
   - Create new project
   - Upload this entire folder
   - Click Deploy!

## Current Size:
Approximately  15M
